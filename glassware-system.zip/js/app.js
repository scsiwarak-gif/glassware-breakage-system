/**
 * Glassware Breakage Recording System - Core Logic
 */

// Global state
let records = [];
let chartByType = null;
let chartByCause = null;
let currentUserRole = sessionStorage.getItem("admin_authenticated") === "true" ? "admin" : "general";
let settings = { glasswareTypes: [], labRooms: [], sizes: [], subjects: [], causes: [] };

// Pagination state
let currentPage = 1;
const recordsPerPage = 10;

// Pre-configured options for dropdown filters
const defaultGlasswareTypes = [
    "Beaker (บีกเกอร์)",
    "Erlenmeyer Flask (ขวดรูปชมพู่)",
    "Graduated Cylinder (กระบอกตวง)",
    "Pipette (ปิเปตต์)",
    "Burette (บิวเรตต์)",
    "Test Tube (หลอดทดลอง)",
    "Volumetric Flask (ขวดกำหนดปริมาตร)",
    "Funnel (กรวยกรอง)",
    "Condenser (คอนเดนเซอร์)"
];

// Document Ready
document.addEventListener("DOMContentLoaded", () => {
    // Initialize Navigation & Routing
    initNavigation();
    
    // Load Records
    records = loadFromStorage();
    
    // Load Settings
    loadSettings();
    
    // Setup Admin Authentication System
    setupAuthSystem();
    
    // Setup select elements dynamically (for filters)
    populateFilterDropdowns();
    
    // If no records, seed initial data as a welcoming state
    if (records.length === 0) {
        seedMockData(false); // seed silently without alert
    }
    
    // Render Dashboard & Records
    updateAppView();
    
    // Attach Event Listeners
    setupFormListeners();
    setupFilterListeners();
    setupActionListeners();
    setupSettingsListeners();
    setupSizesModal();
    
    // Set default datetime to local current time
    resetDateInput();
});

function setupAuthSystem() {
    applyRolePermissions();
    
    // Login Trigger Button
    const loginTrigger = document.getElementById("btn-admin-login-trigger");
    if (loginTrigger) {
        loginTrigger.addEventListener("click", showLoginModal);
    }
    
    // Logout Button
    const logoutBtn = document.getElementById("btn-admin-logout");
    if (logoutBtn) {
        logoutBtn.addEventListener("click", () => {
            sessionStorage.removeItem("admin_authenticated");
            currentUserRole = "general";
            applyRolePermissions();
            updateAppView();
            
            // If editing a record, reset form and redirect to history
            const editId = document.getElementById("edit-id").value;
            if (editId) {
                resetForm();
                switchSection("records");
            }
            showToast("ออกจากระบบผู้ดูแลระบบเรียบร้อยแล้ว", "success");
        });
    }
    
    // Modal buttons
    const closeBtn = document.getElementById("btn-close-login-modal");
    const cancelBtn = document.getElementById("btn-cancel-login");
    const loginForm = document.getElementById("login-form");
    
    if (closeBtn) closeBtn.addEventListener("click", hideLoginModal);
    if (cancelBtn) cancelBtn.addEventListener("click", hideLoginModal);
    
    if (loginForm) {
        loginForm.addEventListener("submit", (e) => {
            e.preventDefault();
            const usernameInput = document.getElementById("login-username").value.trim();
            const passwordInput = document.getElementById("login-password").value;
            
            // Admin Credentials Verification
            if (usernameInput === "admin" && passwordInput === "admin123") {
                sessionStorage.setItem("admin_authenticated", "true");
                currentUserRole = "admin";
                applyRolePermissions();
                updateAppView();
                hideLoginModal();
            } else {
                showToast("ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง", "danger");
            }
        });
    }
}

function showLoginModal() {
    const modal = document.getElementById("login-modal");
    if (modal) {
        document.getElementById("login-password").value = ""; // Clear input
        modal.style.display = "flex";
        document.getElementById("login-password").focus();
    }
}

function hideLoginModal() {
    const modal = document.getElementById("login-modal");
    if (modal) {
        modal.style.display = "none";
    }
}

function applyRolePermissions() {
    // Set class on body for CSS selectors
    document.body.className = currentUserRole === 'general' ? 'role-general' : 'role-admin';
    
    // Update User Profile Card
    const avatarEl = document.getElementById("user-avatar");
    const nameEl = document.getElementById("user-display-name");
    const roleEl = document.getElementById("user-display-role");
    
    if (currentUserRole === "admin") {
        if (avatarEl) { avatarEl.textContent = "A"; avatarEl.style.backgroundColor = "var(--danger)"; }
        if (nameEl) nameEl.textContent = "Lab Admin";
        if (roleEl) roleEl.textContent = "ผู้ดูแลระบบ";
    } else {
        if (avatarEl) { avatarEl.textContent = "G"; avatarEl.style.backgroundColor = "var(--primary)"; }
        if (nameEl) nameEl.textContent = "General Guest";
        if (roleEl) roleEl.textContent = "บุคคลทั่วไป";
    }
}

// --- Data Persistence Layer ---
const STORAGE_KEY = "glassware_breakage_records";

function loadFromStorage() {
    try {
        const stored = localStorage.getItem(STORAGE_KEY);
        return stored ? JSON.parse(stored) : [];
    } catch (e) {
        showToast("ไม่สามารถโหลดข้อมูลได้: " + e.message, "danger");
        return [];
    }
}

function saveToStorage(data) {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (e) {
        showToast("ไม่สามารถบันทึกข้อมูลลงบราวเซอร์ได้: " + e.message, "danger");
    }
}

// --- Navigation & Routing ---
function initNavigation() {
    const navItems = document.querySelectorAll(".nav-item");
    const sections = document.querySelectorAll(".content-section");
    
    const pageTitles = {
        "dashboard": { title: "แดชบอร์ดสรุปสถิติ", subtitle: "รายงานสรุปข้อมูลเครื่องแก้วชำรุดเสียหายในห้องปฏิบัติการ" },
        "records": { title: "ประวัติการชำรุดทั้งหมด", subtitle: "ค้นหา แก้ไข และส่งออกข้อมูลประวัติเครื่องแก้วที่แตกเสียหาย" },
        "add-record": { title: "ลงบันทึกข้อมูลเครื่องแก้วแตก", subtitle: "กรุณากรอกข้อมูลเพื่อเก็บสถิติและวิเคราะห์ความเสียหายในห้องปฏิบัติการ" },
        "settings": { title: "ตั้งค่าระบบปฏิบัติการ", subtitle: "จัดการข้อมูลประเภทเครื่องแก้ว ราคาเริ่มต้น และรายชื่อห้องแล็บ" }
    };
    
    navItems.forEach(item => {
        item.addEventListener("click", (e) => {
            e.preventDefault();
            const targetId = item.getAttribute("href").substring(1);
            switchSection(targetId);
        });
    });
    
    // Support hash change routing
    window.addEventListener("hashchange", () => {
        const hash = window.location.hash.substring(1);
        if (hash === "dashboard" || hash === "records" || hash === "add-record" || hash === "settings") {
            switchSection(hash);
        }
    });
    
    // Initial routing check
    const initialHash = window.location.hash.substring(1);
    if (initialHash) {
        switchSection(initialHash);
    }

    // Setup Settings Tab switching
    const settingsTabs = document.querySelectorAll(".settings-tab");
    settingsTabs.forEach(tab => {
        tab.addEventListener("click", () => {
            // Remove active class from all tabs & panels
            settingsTabs.forEach(t => t.classList.remove("active"));
            document.querySelectorAll(".settings-panel").forEach(p => p.classList.remove("active"));
            
            // Add active class to clicked tab and corresponding panel
            tab.classList.add("active");
            const targetPanelId = tab.getAttribute("data-target");
            const targetPanel = document.getElementById(targetPanelId);
            if (targetPanel) {
                targetPanel.classList.add("active");
            }
        });
    });
}

function switchSection(targetId) {
    // Admin check for settings section
    if (targetId === "settings" && currentUserRole !== "admin") {
        showToast("สิทธิ์การเข้าถึงเมนูตั้งค่าระบบเฉพาะผู้ดูแลระบบเท่านั้น", "danger");
        switchSection("dashboard");
        return;
    }

    const sections = document.querySelectorAll(".content-section");
    const navItems = document.querySelectorAll(".nav-item");
    
    sections.forEach(section => {
        section.style.display = section.id === `section-${targetId}` ? "block" : "none";
    });
    
    navItems.forEach(item => {
        if (item.getAttribute("href") === `#${targetId}`) {
            item.classList.add("active");
        } else {
            item.classList.remove("active");
        }
    });
    
    // Update top bar headings
    const titleObj = {
        "dashboard": { title: "แดชบอร์ดสรุปสถิติ", subtitle: "รายงานสรุปข้อมูลเครื่องแก้วชำรุดเสียหายในห้องปฏิบัติการ" },
        "records": { title: "ประวัติการชำรุดทั้งหมด", subtitle: "ค้นหา แก้ไข และส่งออกข้อมูลประวัติเครื่องแก้วที่แตกเสียหาย" },
        "add-record": { title: "ลงบันทึกข้อมูลเครื่องแก้วแตก", subtitle: "กรุณากรอกข้อมูลเพื่อเก็บสถิติและวิเคราะห์ความเสียหายในห้องปฏิบัติการ" },
        "settings": { title: "ตั้งค่าระบบปฏิบัติการ", subtitle: "จัดการข้อมูลประเภทเครื่องแก้ว ราคาเริ่มต้น และรายชื่อห้องแล็บ" }
    }[targetId];
    
    if (titleObj) {
        document.getElementById("current-page-title").textContent = titleObj.title;
        document.getElementById("current-page-subtitle").textContent = titleObj.subtitle;
    }
    
    // Custom handling when entering views
    if (targetId === "dashboard") {
        updateAppView();
    } else if (targetId === "records") {
        currentPage = 1;
        updateAppView();
    } else if (targetId === "add-record") {
        // Only reset edit form if we aren't in explicit edit mode
        const editId = document.getElementById("edit-id").value;
        if (!editId) {
            resetForm();
        }
    } else if (targetId === "settings") {
        renderSettingsTypes();
        renderSettingsSizes();
        renderSettingsSubjects();
        renderSettingsRooms();
        renderSettingsCauses();
    }
}

// Reset form fields
function resetForm() {
    const form = document.getElementById("record-form");
    form.reset();
    document.getElementById("edit-id").value = "";
    document.getElementById("form-title").textContent = "ลงบันทึกข้อมูลเครื่องแก้วแตก";
    document.getElementById("btn-submit-form").innerHTML = `
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16">
            <path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/>
            <polyline points="17 21 17 13 7 13 7 21"/>
            <polyline points="7 3 7 8 15 8"/>
        </svg>
        บันทึกข้อมูล
    `;
    resetDateInput();
    
    // Hide all custom inputs
    const customGroups = ["subject", "type", "size", "room", "cause"];
    customGroups.forEach(grp => {
        const groupEl = document.getElementById(`custom-${grp}-group`);
        const inputEl = document.getElementById(`field-custom-${grp}`);
        if (groupEl) groupEl.style.display = "none";
        if (inputEl) {
            inputEl.value = "";
            inputEl.removeAttribute("required");
        }
    });
    
    // Repopulate sizes to default select options
    populateSizesDropdownForSelectedType();
    
    // Reset total cost preview
    updateTotalCostPreview();
}

function resetDateInput() {
    const dateInput = document.getElementById("field-date");
    const now = new Date();
    // Format to YYYY-MM-DDTHH:MM
    const tzoffset = now.getTimezoneOffset() * 60000; //offset in milliseconds
    const localISOTime = (new Date(now - tzoffset)).toISOString().slice(0, 16);
    dateInput.value = localISOTime;
}

// Fill filters dynamic dropdowns
function populateFilterDropdowns() {
    const typeFilter = document.getElementById("filter-type");
    const roomFilter = document.getElementById("filter-room");
    const causeFilter = document.getElementById("filter-cause");
    
    if (!typeFilter || !roomFilter || !causeFilter) return;
    
    // Clear and set defaults
    typeFilter.innerHTML = '<option value="">ทุกประเภทเครื่องแก้ว</option>';
    roomFilter.innerHTML = '<option value="">ทุกห้องแล็บ</option>';
    causeFilter.innerHTML = '<option value="">ทุกสาเหตุ</option>';
    
    // Collect unique values from settings + records to be safe
    const uniqueTypes = new Set(settings.glasswareTypes.map(t => t.name));
    const uniqueRooms = new Set(settings.labRooms);
    const uniqueCauses = new Set(settings.causes || []);
    
    records.forEach(r => {
        if (r.type) uniqueTypes.add(r.type);
        if (r.room) uniqueRooms.add(r.room.trim());
        if (r.cause) uniqueCauses.add(r.cause.trim());
    });
    
    // Populate Type filter
    Array.from(uniqueTypes).sort().forEach(type => {
        const opt = document.createElement("option");
        opt.value = type;
        opt.textContent = type;
        typeFilter.appendChild(opt);
    });
    
    // Populate Room filter
    Array.from(uniqueRooms).sort().forEach(room => {
        const opt = document.createElement("option");
        opt.value = room;
        opt.textContent = room;
        roomFilter.appendChild(opt);
    });

    // Populate Cause filter
    Array.from(uniqueCauses).sort().forEach(cause => {
        const opt = document.createElement("option");
        opt.value = cause;
        opt.textContent = cause;
        causeFilter.appendChild(opt);
    });
}

// --- Data Visualizations & Analytics ---
function updateDashboardMetrics() {
    // Calculators
    let totalItems = 0;
    let totalCost = 0.0;
    let causeCounts = {};
    
    records.forEach(r => {
        const qty = parseInt(r.quantity) || 0;
        const price = parseFloat(r.price) || 0.0;
        totalItems += qty;
        totalCost += (qty * price);
        
        const cause = r.cause || "อื่นๆ";
        causeCounts[cause] = (causeCounts[cause] || 0) + qty;
    });
    
    // Render KPIs
    document.getElementById("kpi-total-items").innerHTML = `${totalItems.toLocaleString()} <span class="unit">ชิ้น</span>`;
    document.getElementById("kpi-total-records-count").textContent = `ทั้งหมด ${records.length.toLocaleString()} รายการ`;
    
    document.getElementById("kpi-total-cost").innerHTML = `${totalCost.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})} <span class="unit">บาท</span>`;
    
    const avgCost = totalItems > 0 ? (totalCost / totalItems) : 0.0;
    document.getElementById("kpi-avg-cost").textContent = `เฉลี่ย ${avgCost.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})} บาท/ชิ้น`;
    
    // Top cause determination
    let topCause = "-";
    let topCauseCount = 0;
    Object.keys(causeCounts).forEach(cause => {
        if (causeCounts[cause] > topCauseCount) {
            topCause = cause;
            topCauseCount = causeCounts[cause];
        }
    });
    
    const pct = totalItems > 0 ? ((topCauseCount / totalItems) * 100).toFixed(0) : 0;
    
    document.getElementById("kpi-top-cause").textContent = topCause;
    document.getElementById("kpi-top-cause-pct").textContent = totalItems > 0 ? `อัตราส่วน ${pct}% ของทั้งหมด` : "ไม่มีข้อมูลสถิติ";
}

function updateCharts() {
    // Aggregate by type
    let typeData = {};
    let causeData = {};
    
    records.forEach(r => {
        const qty = parseInt(r.quantity) || 0;
        
        typeData[r.type] = (typeData[r.type] || 0) + qty;
        causeData[r.cause] = (causeData[r.cause] || 0) + qty;
    });
    
    // Color palettes for Chart.js matching our theme
    const sagePalette = [
        '#6B8E6B', // sage
        '#8FA39B', // teal
        '#A5BAA5', // light sage
        '#DE935F', // ochre
        '#CB6B6B', // coral red
        '#5F939A', // denim blue
        '#D6DFD0', // sand
        '#8A9A86', // dark olive sage
        '#B3CBB9'  // soft pale green
    ];
    
    // 1. Chart by Glassware Type
    const typeCanvas = document.getElementById("chart-by-type");
    if (chartByType) {
        chartByType.destroy();
    }
    
    const typeLabels = Object.keys(typeData);
    const typeValues = Object.values(typeData);
    
    if (typeLabels.length === 0) {
        // Fallback for empty state
        typeLabels.push("ไม่มีข้อมูล");
        typeValues.push(1);
    }
    
    chartByType = new Chart(typeCanvas, {
        type: 'doughnut',
        data: {
            labels: typeLabels,
            datasets: [{
                data: typeValues,
                backgroundColor: sagePalette.slice(0, typeLabels.length),
                borderWidth: 2,
                borderColor: '#ffffff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                    labels: {
                        font: { family: 'Outfit, Noto Sans Thai', size: 12 },
                        color: '#2C3530'
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            if (records.length === 0) return "ไม่มีข้อมูลชำรุด";
                            const val = context.raw;
                            return ` ชำรุด: ${val} ชิ้น`;
                        }
                    }
                }
            },
            cutout: '65%'
        }
    });
    
    // 2. Chart by Breakage Cause
    const causeCanvas = document.getElementById("chart-by-cause");
    if (chartByCause) {
        chartByCause.destroy();
    }
    
    const causeLabels = Object.keys(causeData);
    const causeValues = Object.values(causeData);
    
    chartByCause = new Chart(causeCanvas, {
        type: 'bar',
        data: {
            labels: causeLabels.length > 0 ? causeLabels : ["ไม่มีข้อมูล"],
            datasets: [{
                label: 'จำนวนเครื่องแก้วที่แตก (ชิ้น)',
                data: causeValues.length > 0 ? causeValues : [0],
                backgroundColor: '#8FA39B',
                borderRadius: 6,
                barThickness: 24
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                x: {
                    grid: { display: false },
                    ticks: {
                        font: { family: 'Outfit, Noto Sans Thai', size: 11 },
                        color: '#2C3530'
                    }
                },
                y: {
                    grid: { color: '#E9EFEA' },
                    ticks: {
                        font: { family: 'Outfit', size: 11 },
                        color: '#2C3530',
                        stepSize: 1
                    }
                }
            }
        }
    });
}

// --- List Renderings ---
function renderRecentRecords() {
    const tbody = document.getElementById("recent-records-tbody");
    tbody.innerHTML = "";
    
    // Get last 5 records sorted by date descending
    const sorted = [...records].sort((a, b) => new Date(b.date) - new Date(a.date));
    const recent = sorted.slice(0, 5);
    
    if (recent.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" class="empty-state">ไม่มีข้อมูลบันทึกในระบบ</td></tr>`;
        return;
    }
    
    recent.forEach(r => {
        const row = document.createElement("tr");
        
        const dateFormatted = formatDate(r.date);
        
        row.innerHTML = `
            <td><strong>${dateFormatted}</strong></td>
            <td>
                <span class="glassware-name">${r.type}</span><br>
                <small style="color:var(--text-muted)">ขนาด: ${r.size}</small>
            </td>
            <td><strong>${r.subject || "-"}</strong></td>
            <td>${r.room}</td>
            <td><span class="badge" style="background-color:var(--danger-light); color:var(--danger); padding:4px 8px; border-radius:4px; font-weight:600">${r.quantity} ชิ้น</span></td>
            <td>${r.reporter}</td>
        `;
        tbody.appendChild(row);
    });
}

function renderRecordsTable() {
    const tbody = document.getElementById("records-tbody");
    tbody.innerHTML = "";
    
    // Get values from filters
    const searchVal = document.getElementById("search-input").value.toLowerCase().trim();
    const typeFilter = document.getElementById("filter-type").value;
    const roomFilter = document.getElementById("filter-room").value;
    const causeFilter = document.getElementById("filter-cause").value;
    
    // Apply filters
    let filtered = records.filter(r => {
        const matchesSearch = 
            r.type.toLowerCase().includes(searchVal) ||
            r.reporter.toLowerCase().includes(searchVal) ||
            (r.notes && r.notes.toLowerCase().includes(searchVal)) ||
            (r.subject && r.subject.toLowerCase().includes(searchVal)) ||
            r.room.toLowerCase().includes(searchVal);
            
        const matchesType = !typeFilter || r.type === typeFilter;
        const matchesRoom = !roomFilter || r.room === roomFilter;
        const matchesCause = !causeFilter || r.cause === causeFilter;
        
        return matchesSearch && matchesType && matchesRoom && matchesCause;
    });
    
    // Sort filtered records by date descending
    filtered.sort((a, b) => new Date(b.date) - new Date(a.date));
    
    const totalFiltered = filtered.length;
    
    // Handle pagination bounds
    const startIndex = (currentPage - 1) * recordsPerPage;
    const endIndex = Math.min(startIndex + recordsPerPage, totalFiltered);
    const paginated = filtered.slice(startIndex, endIndex);
    
    // Empty state check
    if (totalFiltered === 0) {
        tbody.innerHTML = `<tr><td colspan="12" class="empty-state">ไม่พบข้อมูลบันทึกที่ตรงตามเงื่อนไขค้นหา</td></tr>`;
        document.getElementById("pagination-text").textContent = "แสดง 0 ถึง 0 จากทั้งหมด 0 รายการ";
        document.getElementById("pagination-controls").innerHTML = "";
        return;
    }
    
    // Render Paginated records
    paginated.forEach(r => {
        const row = document.createElement("tr");
        const price = parseFloat(r.price) || 0.0;
        const qty = parseInt(r.quantity) || 0;
        const cost = price * qty;
        
        const priceStr = price > 0 ? price.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}) : "-";
        const costStr = cost > 0 ? cost.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}) : "-";
        
        row.innerHTML = `
            <td><strong>${formatDate(r.date)}</strong></td>
            <td><strong>${r.type}</strong></td>
            <td>${r.size}</td>
            <td>${priceStr}</td>
            <td><strong style="color:var(--danger)">${qty}</strong></td>
            <td><strong style="color:var(--danger)">${costStr}</strong></td>
            <td><strong>${r.subject || "-"}</strong></td>
            <td>${r.room}</td>
            <td><span class="badge" style="background-color:rgba(222,147,95,0.15); color:var(--warning); padding:3px 6px; border-radius:4px; font-weight:600; font-size:0.8rem">${r.cause}</span></td>
            <td>${r.reporter}</td>
            <td><small style="display:block; max-width: 150px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${r.notes || ''}">${r.notes || '-'}</small></td>
            <td class="actions-col admin-only">
                <div class="action-buttons-wrap">
                    <button class="btn-icon btn-icon-edit" data-id="${r.id}" title="แก้ไขบันทึก">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16">
                            <path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7" />
                            <path d="M18.5 2.5a2.121 2.121 0 113 3L12 15l-4 1 1-4 9.5-9.5z" />
                        </svg>
                    </button>
                    <button class="btn-icon btn-icon-delete" data-id="${r.id}" title="ลบข้อมูล">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16">
                            <polyline points="3 6 5 6 21 6" />
                            <path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2" />
                            <line x1="10" y1="11" x2="10" y2="17" />
                            <line x1="14" y1="11" x2="14" y2="17" />
                        </svg>
                    </button>
                </div>
            </td>
        `;
        tbody.appendChild(row);
    });
    
    // Update Pagination display
    document.getElementById("pagination-text").textContent = `แสดง ${startIndex + 1} ถึง ${endIndex} จากทั้งหมด ${totalFiltered} รายการ` + 
        (totalFiltered !== records.length ? ` (กรองจากทั้งหมด ${records.length} รายการ)` : "");
        
    renderPaginationControls(totalFiltered);
    attachTableActionListeners();
}

function renderPaginationControls(totalItems) {
    const container = document.getElementById("pagination-controls");
    container.innerHTML = "";
    
    const totalPages = Math.ceil(totalItems / recordsPerPage);
    if (totalPages <= 1) return; // No pagination controls needed
    
    // Previous Button
    const prevBtn = document.createElement("button");
    prevBtn.className = "pagination-btn";
    prevBtn.textContent = "« ก่อนหน้า";
    prevBtn.disabled = currentPage === 1;
    prevBtn.addEventListener("click", () => {
        if (currentPage > 1) {
            currentPage--;
            renderRecordsTable();
        }
    });
    container.appendChild(prevBtn);
    
    // Page Number Buttons
    for (let i = 1; i <= totalPages; i++) {
        const btn = document.createElement("button");
        btn.className = `pagination-btn ${i === currentPage ? 'active' : ''}`;
        btn.textContent = i;
        btn.addEventListener("click", () => {
            currentPage = i;
            renderRecordsTable();
        });
        container.appendChild(btn);
    }
    
    // Next Button
    const nextBtn = document.createElement("button");
    nextBtn.className = "pagination-btn";
    nextBtn.textContent = "ถัดไป »";
    nextBtn.disabled = currentPage === totalPages;
    nextBtn.addEventListener("click", () => {
        if (currentPage < totalPages) {
            currentPage++;
            renderRecordsTable();
        }
    });
    container.appendChild(nextBtn);
}

// Master view update coordinator
function updateAppView() {
    updateDashboardMetrics();
    updateCharts();
    renderRecentRecords();
    renderRecordsTable();
}

// Helper: Format Date string for display
function formatDate(dateStr) {
    if (!dateStr) return "-";
    const dateObj = new Date(dateStr);
    if (isNaN(dateObj)) return dateStr;
    
    const thMonths = [
        "ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.",
        "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค."
    ];
    
    const day = dateObj.getDate();
    const month = thMonths[dateObj.getMonth()];
    const year = dateObj.getFullYear() + 543; // Thai Buddhist Year
    
    const hour = String(dateObj.getHours()).padStart(2, '0');
    const minute = String(dateObj.getMinutes()).padStart(2, '0');
    
    return `${day} ${month} ${String(year).slice(-2)} - ${hour}:${minute} น.`;
}

// --- Listeners & Handlers ---

function setupFormListeners() {
    const form = document.getElementById("record-form");
    
    const subjectSelect = document.getElementById("field-subject");
    const customSubjectGroup = document.getElementById("custom-subject-group");
    const customSubjectInput = document.getElementById("field-custom-subject");

    const typeSelect = document.getElementById("field-type");
    const customTypeGroup = document.getElementById("custom-type-group");
    const customTypeInput = document.getElementById("field-custom-type");
    
    const sizeSelect = document.getElementById("field-size");
    const customSizeGroup = document.getElementById("custom-size-group");
    const customSizeInput = document.getElementById("field-custom-size");

    const roomSelect = document.getElementById("field-room");
    const customRoomGroup = document.getElementById("custom-room-group");
    const customRoomInput = document.getElementById("field-custom-room");
    
    const causeSelect = document.getElementById("field-cause");
    const customCauseGroup = document.getElementById("custom-cause-group");
    const customCauseInput = document.getElementById("field-custom-cause");

    const cancelBtn = document.getElementById("btn-cancel-form");
    
    // Toggle custom subject field
    subjectSelect.addEventListener("change", () => {
        if (subjectSelect.value === "อื่นๆ") {
            customSubjectGroup.style.display = "block";
            customSubjectInput.setAttribute("required", "true");
            customSubjectInput.focus();
        } else {
            customSubjectGroup.style.display = "none";
            customSubjectInput.removeAttribute("required");
        }
    });

    // Autofill default price and toggle custom type field
    typeSelect.addEventListener("change", () => {
        const val = typeSelect.value;
        if (val === "อื่นๆ") {
            customTypeGroup.style.display = "block";
            customTypeInput.setAttribute("required", "true");
            customTypeInput.focus();
        } else {
            customTypeGroup.style.display = "none";
            customTypeInput.removeAttribute("required");
        }
        
        // Repopulate sizes based on selected type
        populateSizesDropdownForSelectedType();
        
        // Reset price and update preview
        document.getElementById("field-price").value = "";
        updateTotalCostPreview();
    });
    
    // Toggle custom size field
    sizeSelect.addEventListener("change", () => {
        const val = sizeSelect.value;
        if (val === "อื่นๆ") {
            customSizeGroup.style.display = "block";
            customSizeInput.setAttribute("required", "true");
            customSizeInput.focus();
            
            // Reset price field
            document.getElementById("field-price").value = "";
        } else {
            customSizeGroup.style.display = "none";
            customSizeInput.removeAttribute("required");
            
            // Lookup price based on selected type and size
            const typeVal = typeSelect.value;
            if (typeVal && typeVal !== "อื่นๆ") {
                const foundType = settings.glasswareTypes.find(t => t.name === typeVal);
                if (foundType && foundType.sizes) {
                    const foundSize = foundType.sizes.find(s => s.name === val);
                    if (foundSize) {
                        document.getElementById("field-price").value = foundSize.price;
                    } else {
                        document.getElementById("field-price").value = "";
                    }
                } else {
                    document.getElementById("field-price").value = "";
                }
            } else {
                document.getElementById("field-price").value = "";
            }
        }
        
        // Update total cost preview
        updateTotalCostPreview();
    });

    // Toggle custom room field
    roomSelect.addEventListener("change", () => {
        if (roomSelect.value === "อื่นๆ") {
            customRoomGroup.style.display = "block";
            customRoomInput.setAttribute("required", "true");
            customRoomInput.focus();
        } else {
            customRoomGroup.style.display = "none";
            customRoomInput.removeAttribute("required");
        }
    });

    // Toggle custom cause field
    causeSelect.addEventListener("change", () => {
        if (causeSelect.value === "อื่นๆ") {
            customCauseGroup.style.display = "block";
            customCauseInput.setAttribute("required", "true");
            customCauseInput.focus();
        } else {
            customCauseGroup.style.display = "none";
            customCauseInput.removeAttribute("required");
        }
    });
    
    // Handle form submit
    form.addEventListener("submit", (e) => {
        e.preventDefault();
        
        const editId = document.getElementById("edit-id").value;
        const dateVal = document.getElementById("field-date").value;
        const reporterVal = document.getElementById("field-reporter").value.trim();
        
        const subjectSelectVal = subjectSelect.value;
        const customSubjectVal = customSubjectInput.value.trim();

        const typeSelectVal = typeSelect.value;
        const customTypeVal = customTypeInput.value.trim();

        const sizeSelectVal = sizeSelect.value;
        const customSizeVal = customSizeInput.value.trim();

        const priceVal = parseFloat(document.getElementById("field-price").value) || 0.0;
        const qtyVal = parseInt(document.getElementById("field-quantity").value) || 1;
        
        const roomSelectVal = roomSelect.value;
        const customRoomVal = customRoomInput.value.trim();
        
        const causeSelectVal = causeSelect.value;
        const customCauseVal = customCauseInput.value.trim();

        const notesVal = document.getElementById("field-notes").value.trim();
        
        // Final determinations
        const finalSubject = subjectSelectVal === "อื่นๆ" ? customSubjectVal : subjectSelectVal;
        const finalType = typeSelectVal === "อื่นๆ" ? customTypeVal : typeSelectVal;
        const finalSize = sizeSelectVal === "อื่นๆ" ? customSizeVal : sizeSelectVal;
        const finalRoom = roomSelectVal === "อื่นๆ" ? customRoomVal : roomSelectVal;
        const finalCause = causeSelectVal === "อื่นๆ" ? customCauseVal : causeSelectVal;
        
        if (!finalSubject) {
            showToast("กรุณาระบุรายวิชา / รหัสวิชา", "warning");
            return;
        }
        if (!finalType) {
            showToast("กรุณาระบุประเภทเครื่องแก้ว", "warning");
            return;
        }
        if (!finalSize) {
            showToast("กรุณาระบุขนาด / ความจุ", "warning");
            return;
        }
        if (!finalRoom) {
            showToast("กรุณาระบุห้องปฏิบัติการ", "warning");
            return;
        }
        if (!finalCause) {
            showToast("กรุณาระบุสาเหตุของการชำรุด", "warning");
            return;
        }
        
        if (editId) {
            // Edit Mode - Admin check
            if (currentUserRole !== "admin") {
                showToast("มีเพียงผู้ดูแลระบบเท่านั้นที่สามารถแก้ไขข้อมูลได้", "danger");
                return;
            }
            const index = records.findIndex(r => r.id === editId);
            if (index !== -1) {
                records[index] = {
                    ...records[index],
                    date: dateVal,
                    reporter: reporterVal,
                    subject: finalSubject,
                    type: finalType,
                    size: finalSize,
                    price: priceVal,
                    quantity: qtyVal,
                    room: finalRoom,
                    cause: finalCause,
                    notes: notesVal
                };
                showToast("แก้ไขข้อมูลรายการเครื่องแก้วสำเร็จ", "success");
            } else {
                showToast("ไม่พบข้อมูลที่จะแก้ไข", "danger");
            }
        } else {
            // Create Mode
            const newRecord = {
                id: Date.now().toString(),
                date: dateVal,
                reporter: reporterVal,
                subject: finalSubject,
                type: finalType,
                size: finalSize,
                price: priceVal,
                quantity: qtyVal,
                room: finalRoom,
                cause: finalCause,
                notes: notesVal
            };
            records.push(newRecord);
        }
        
        // Save
        saveToStorage(records);
        
        // Refresh dynamic dropdown filters
        populateFilterDropdowns();
        
        // Reset and redirect
        resetForm();
        switchSection("records");
    });
    
    // Price and quantity input changes call updateTotalCostPreview
    const priceInput = document.getElementById("field-price");
    const qtyInput = document.getElementById("field-quantity");
    if (priceInput) priceInput.addEventListener("input", updateTotalCostPreview);
    if (qtyInput) qtyInput.addEventListener("input", updateTotalCostPreview);

    // Cancel button
    cancelBtn.addEventListener("click", () => {
        resetForm();
        switchSection("dashboard");
    });
}

function setupFilterListeners() {
    const searchInput = document.getElementById("search-input");
    const filterType = document.getElementById("filter-type");
    const filterRoom = document.getElementById("filter-room");
    const filterCause = document.getElementById("filter-cause");
    
    const triggerSearch = () => {
        currentPage = 1; // reset to page 1 on filter trigger
        renderRecordsTable();
    };
    
    searchInput.addEventListener("input", triggerSearch);
    filterType.addEventListener("change", triggerSearch);
    filterRoom.addEventListener("change", triggerSearch);
    filterCause.addEventListener("change", triggerSearch);
}

function setupActionListeners() {
    // Seed Demo Data button
    document.getElementById("btn-seed").addEventListener("click", () => {
        seedMockData(true);
    });
    
    // Export CSV
    document.getElementById("btn-export-csv").addEventListener("click", exportCSV);
    
    // Export JSON/Import JSON trigger
    const importTrigger = document.getElementById("btn-import-json-trigger");
    const fileInput = document.getElementById("import-json-file");
    
    importTrigger.addEventListener("click", () => {
        fileInput.click();
    });
    
    fileInput.addEventListener("change", importJSON);
    
    // Clear All
    document.getElementById("btn-clear-all").addEventListener("click", () => {
        if (confirm("คุณแน่ใจหรือไม่ที่จะลบข้อมูลบันทึกทั้งหมดออกจากระบบ? การกระทำนี้ไม่สามารถย้อนกลับได้")) {
            records = [];
            saveToStorage(records);
            populateFilterDropdowns();
            updateAppView();
            showToast("ล้างข้อมูลทั้งหมดสำเร็จแล้ว", "success");
        }
    });
}

function attachTableActionListeners() {
    // Edit Action buttons
    document.querySelectorAll(".btn-icon-edit").forEach(btn => {
        btn.addEventListener("click", () => {
            if (currentUserRole !== "admin") {
                showToast("สิทธิ์ผู้ใช้งานทั่วไป ไม่สามารถแก้ไขข้อมูลได้", "danger");
                return;
            }
            const id = btn.getAttribute("data-id");
            const record = records.find(r => r.id === id);
            if (record) {
                // Prepare form
                document.getElementById("edit-id").value = record.id;
                document.getElementById("field-date").value = record.date;
                document.getElementById("field-reporter").value = record.reporter;
                
                // 1. Determine subject field state
                const subjectSelect = document.getElementById("field-subject");
                const customSubjectGroup = document.getElementById("custom-subject-group");
                const customSubjectInput = document.getElementById("field-custom-subject");
                if (settings.subjects.includes(record.subject)) {
                    subjectSelect.value = record.subject;
                    customSubjectGroup.style.display = "none";
                    customSubjectInput.value = "";
                    customSubjectInput.removeAttribute("required");
                } else {
                    subjectSelect.value = "อื่นๆ";
                    customSubjectGroup.style.display = "block";
                    customSubjectInput.value = record.subject || "";
                    customSubjectInput.setAttribute("required", "true");
                }

                // 2. Determine type field state
                const typeSelect = document.getElementById("field-type");
                const customTypeGroup = document.getElementById("custom-type-group");
                const customTypeInput = document.getElementById("field-custom-type");
                const settingsTypeNames = settings.glasswareTypes.map(t => t.name);
                if (settingsTypeNames.includes(record.type)) {
                    typeSelect.value = record.type;
                    customTypeGroup.style.display = "none";
                    customTypeInput.value = "";
                    customTypeInput.removeAttribute("required");
                } else {
                    typeSelect.value = "อื่นๆ";
                    customTypeGroup.style.display = "block";
                    customTypeInput.value = record.type;
                    customTypeInput.setAttribute("required", "true");
                }
                
                // Repopulate sizes dropdown based on the type we just set!
                populateSizesDropdownForSelectedType();
                
                // 3. Determine size field state
                const sizeSelect = document.getElementById("field-size");
                const customSizeGroup = document.getElementById("custom-size-group");
                const customSizeInput = document.getElementById("field-custom-size");
                
                let sizeExistsInOptions = false;
                if (typeSelect.value === "อื่นๆ") {
                    sizeExistsInOptions = settings.sizes.includes(record.size);
                } else {
                    const foundType = settings.glasswareTypes.find(t => t.name === typeSelect.value);
                    if (foundType && foundType.sizes) {
                        sizeExistsInOptions = foundType.sizes.some(s => s.name === record.size);
                    }
                }
                
                if (sizeExistsInOptions) {
                    sizeSelect.value = record.size;
                    customSizeGroup.style.display = "none";
                    customSizeInput.value = "";
                    customSizeInput.removeAttribute("required");
                } else {
                    sizeSelect.value = "อื่นๆ";
                    customSizeGroup.style.display = "block";
                    customSizeInput.value = record.size;
                    customSizeInput.setAttribute("required", "true");
                }

                // 4. Determine room field state
                const roomSelect = document.getElementById("field-room");
                const customRoomGroup = document.getElementById("custom-room-group");
                const customRoomInput = document.getElementById("field-custom-room");
                if (settings.labRooms.includes(record.room)) {
                    roomSelect.value = record.room;
                    customRoomGroup.style.display = "none";
                    customRoomInput.value = "";
                    customRoomInput.removeAttribute("required");
                } else {
                    roomSelect.value = "อื่นๆ";
                    customRoomGroup.style.display = "block";
                    customRoomInput.value = record.room;
                    customRoomInput.setAttribute("required", "true");
                }

                // 5. Determine cause field state
                const causeSelect = document.getElementById("field-cause");
                const customCauseGroup = document.getElementById("custom-cause-group");
                const customCauseInput = document.getElementById("field-custom-cause");
                if (settings.causes.includes(record.cause)) {
                    causeSelect.value = record.cause;
                    customCauseGroup.style.display = "none";
                    customCauseInput.value = "";
                    customCauseInput.removeAttribute("required");
                } else {
                    causeSelect.value = "อื่นๆ";
                    customCauseGroup.style.display = "block";
                    customCauseInput.value = record.cause || "";
                    customCauseInput.setAttribute("required", "true");
                }
                
                document.getElementById("field-price").value = record.price;
                document.getElementById("field-quantity").value = record.quantity;
                document.getElementById("field-notes").value = record.notes || "";
                
                // Update total cost preview
                updateTotalCostPreview();
                
                // Change UI Title & Button text
                document.getElementById("form-title").textContent = "แก้ไขบันทึกประวัติเครื่องแก้วแตก";
                document.getElementById("btn-submit-form").innerHTML = `
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16">
                        <path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/>
                        <polyline points="17 21 17 13 7 13 7 21"/>
                        <polyline points="7 3 7 8 15 8"/>
                    </svg>
                    บันทึกการแก้ไข
                `;
                
                // Switch Tab
                switchSection("add-record");
            }
        });
    });
    
    // Delete Action buttons
    document.querySelectorAll(".btn-icon-delete").forEach(btn => {
        btn.addEventListener("click", () => {
            if (currentUserRole !== "admin") {
                showToast("สิทธิ์ผู้ใช้งานทั่วไป ไม่สามารถลบข้อมูลได้", "danger");
                return;
            }
            const id = btn.getAttribute("data-id");
            records = records.filter(r => r.id !== id);
            saveToStorage(records);
            populateFilterDropdowns();
            updateAppView();
        });
    });
}

// --- CSV Export Logic (Excel Thai support via BOM) ---
function exportCSV() {
    if (records.length === 0) {
        showToast("ไม่มีข้อมูลให้ออกรายงาน", "warning");
        return;
    }
    
    // Headers
    const headers = [
        "วันที่-เวลา", 
        "ประเภทเครื่องแก้ว", 
        "ขนาด/ความจุ", 
        "ราคาต่อชิ้น (บาท)", 
        "จำนวนชิ้น", 
        "มูลค่ารวม (บาท)", 
        "รายวิชา",
        "ห้องปฏิบัติการ", 
        "สาเหตุการชำรุด", 
        "ผู้บันทึก", 
        "หมายเหตุ"
    ];
    
    // Build Rows
    const rows = records.map(r => {
        const price = parseFloat(r.price) || 0.0;
        const qty = parseInt(r.quantity) || 0;
        const cost = price * qty;
        
        return [
            r.date.replace("T", " "),
            r.type,
            r.size,
            price,
            qty,
            cost,
            r.subject || "-",
            r.room,
            r.cause,
            r.reporter,
            (r.notes || "").replace(/\n/g, " ")
        ];
    });
    
    // Combine
    let csvContent = headers.join(",") + "\n" + rows.map(e => e.map(val => `"${String(val).replace(/"/g, '""')}"`).join(",")).join("\n");
    
    // Create download element with UTF-8 BOM representation to ensure Excel decodes Thai letters correctly
    const blob = new Blob(["\ufeff" + csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    
    link.setAttribute("href", url);
    link.setAttribute("download", `glassware_breakage_report_${new Date().toISOString().slice(0,10)}.csv`);
    link.style.visibility = 'hidden';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    showToast("ส่งออกข้อมูลเป็น CSV สำเร็จแล้ว", "success");
}

// --- JSON Import/Backup Logic ---
function importJSON(e) {
    const file = e.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(evt) {
        try {
            const imported = JSON.parse(evt.target.result);
            if (!Array.isArray(imported)) {
                throw new Error("ข้อมูลนำเข้าไม่ได้อยู่ในรูปแบบรายการอาร์เรย์");
            }
            
            // Basic validation
            let isValid = true;
            for (let i = 0; i < Math.min(imported.length, 5); i++) {
                const item = imported[i];
                if (!item.id || !item.type || !item.quantity || !item.date) {
                    isValid = false;
                    break;
                }
            }
            
            if (!isValid) {
                throw new Error("โครงสร้างข้อมูลในไฟล์มีความเสียหายหรือไม่ถูกต้องตามมาตรฐานระบบ");
            }
            
            // Merge or replace options
            if (confirm(`พบข้อมูลนำเข้าจำนวน ${imported.length} รายการ ต้องการล้างข้อมูลเดิมและเขียนทับใช่หรือไม่? (คลิกตกลงเพื่อเริ่มเขียนทับ หรือยกเลิกเพื่อเขียนต่อท้าย)`)) {
                records = imported;
            } else {
                // Merge based on non-duplicated ID
                const existingIds = new Set(records.map(r => r.id));
                imported.forEach(r => {
                    if (!existingIds.has(r.id)) {
                        records.push(r);
                    }
                });
            }
            
            saveToStorage(records);
            populateFilterDropdowns();
            updateAppView();
            showToast(`นำเข้าข้อมูลประวัติจำนวน ${imported.length} รายการสำเร็จ`, "success");
        } catch (err) {
            showToast("ล้มเหลวในการนำเข้าไฟล์ JSON: " + err.message, "danger");
        }
    };
    reader.readAsText(file);
    
    // reset target file value to allow re-uploading same file
    e.target.value = "";
}

// --- Mock Data Seed Generator ---
function seedMockData(showAlert = true) {
    const staffNames = [
        "ดร.ปภัสสร นิยมไทย", "สมชาย เข็มทิศ", "กิตติพงษ์ แก้วสะอาด", 
        "พิมลวรรณ สุขวิไล", "ธีรดล เลิศศิลป์", "สุนิสา วงศ์ธรรม"
    ];
    
    const labRooms = [
        "ห้องแล็บเคมีอินทรีย์ 302", "ห้องปฏิบัติการเคมีทั่วไป 101", 
        "ห้องวิเคราะห์คุณภาพน้ำ 405", "ห้องแล็บชีววิทยา 205"
    ];

    const subjects = [
        "ว30221 เคมี 1", "ว30222 เคมี 2", "ว30223 เคมี 3",
        "แล็บเคมีวิเคราะห์ SC211", "แล็บเคมีอินทรีย์ SC212", 
        "วิทยาศาสตร์กายภาพทั่วไป", "การทดลองโครงการวิทยาศาสตร์"
    ];
    
    const causes = [
        "ลื่นหลุดมือ", "แตกขณะล้าง", "อุณหภูมิเปลี่ยนฉับพลัน", 
        "กระทบกันขณะเคลื่อนย้าย"
    ];
    
    const itemCatalog = [
        { type: "Beaker (บีกเกอร์)", sizes: ["100 mL", "250 mL", "500 mL", "1000 mL"], priceRange: [120, 280] },
        { type: "Erlenmeyer Flask (ขวดรูปชมพู่)", sizes: ["250 mL", "500 mL"], priceRange: [150, 320] },
        { type: "Graduated Cylinder (กระบอกตวง)", sizes: ["10 mL", "50 mL", "100 mL"], priceRange: [220, 480] },
        { type: "Pipette (ปิเปตต์)", sizes: ["10 mL", "25 mL"], priceRange: [280, 540] },
        { type: "Burette (บิวเรตต์)", sizes: ["50 mL"], priceRange: [750, 1200] },
        { type: "Test Tube (หลอดทดลอง)", sizes: ["15x150 mm", "20x150 mm"], priceRange: [15, 35] },
        { type: "Volumetric Flask (ขวดกำหนดปริมาตร)", sizes: ["100 mL", "250 mL", "500 mL"], priceRange: [450, 850] }
    ];
    
    let seeded = [];
    const now = new Date();
    
    // Create 15 realistic historical records spread over 30 days
    for (let i = 0; i < 15; i++) {
        const catalogItem = itemCatalog[Math.floor(Math.random() * itemCatalog.length)];
        const size = catalogItem.sizes[Math.floor(Math.random() * catalogItem.sizes.length)];
        const price = Math.round(catalogItem.priceRange[0] + Math.random() * (catalogItem.priceRange[1] - catalogItem.priceRange[0]));
        const quantity = Math.floor(Math.random() * 3) + 1; // 1 to 3 items
        
        // Pick random past date
        const dateObj = new Date(now);
        dateObj.setDate(now.getDate() - Math.floor(Math.random() * 25));
        dateObj.setHours(9 + Math.floor(Math.random() * 8));
        dateObj.setMinutes(Math.floor(Math.random() * 12) * 5);
        
        // Format ISO String offset to system locale
        const tzoffset = dateObj.getTimezoneOffset() * 60000;
        const formattedDate = (new Date(dateObj - tzoffset)).toISOString().slice(0, 16);
        
        seeded.push({
            id: `seed_${i}_${Date.now()}`,
            date: formattedDate,
            reporter: staffNames[Math.floor(Math.random() * staffNames.length)],
            type: catalogItem.type,
            size: size,
            price: price,
            quantity: quantity,
            subject: subjects[Math.floor(Math.random() * subjects.length)],
            room: labRooms[Math.floor(Math.random() * labRooms.length)],
            cause: causes[Math.floor(Math.random() * causes.length)],
            notes: Math.random() > 0.6 ? "เกิดอุบัติเหตุเนื่องจากสวมถุงมือหนาเกินไปทำให้การหยิบจับคลาดเคลื่อน" : ""
        });
    }
    
    // Save to global and localStorage
    records = seeded;
    saveToStorage(records);
    populateFilterDropdowns();
    updateAppView();
    
    if (showAlert) {
        showToast("จำลองข้อมูลตัวอย่างจำนวน 15 รายการสำเร็จแล้ว", "success");
    }
}

// --- Custom Notification Toast ---
function showToast(message, type = "success") {
    const container = document.getElementById("toast-container");
    if (!container) return;
    
    const toast = document.createElement("div");
    toast.className = `toast toast-${type}`;
    
    // SVG icons matching status type
    let iconSvg = '';
    if (type === 'success') {
        iconSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><path d="M22 11.08V12a10 10 0 11-5.93-9.14M22 4L12 14.01l-3-3"/></svg>';
    } else if (type === 'danger') {
        iconSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>';
    } else if (type === 'warning') {
        iconSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/></svg>';
    } else {
        iconSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>';
    }
    
    toast.innerHTML = `
        <div style="display:flex; align-items:center; gap:0.5rem">
            ${iconSvg}
            <span class="toast-message">${message}</span>
        </div>
    `;
    
    container.appendChild(toast);
    
    // Automatically dismiss after 4 seconds
    setTimeout(() => {
        toast.classList.add("fade-out");
        toast.addEventListener("transitionend", () => {
            toast.remove();
        });
    }, 4000);
}

// --- Settings Management ---
const SETTINGS_KEY = "glassware_logger_settings";

const defaultGlasswareSettings = [
    {
        name: "Beaker (บีกเกอร์)",
        sizes: [
            { name: "50 mL", price: 100 },
            { name: "100 mL", price: 120 },
            { name: "250 mL", price: 150 },
            { name: "500 mL", price: 200 },
            { name: "1000 mL", price: 350 }
        ]
    },
    {
        name: "Erlenmeyer Flask (ขวดรูปชมพู่)",
        sizes: [
            { name: "50 mL", price: 120 },
            { name: "100 mL", price: 150 },
            { name: "250 mL", price: 180 },
            { name: "500 mL", price: 240 },
            { name: "1000 mL", price: 400 }
        ]
    },
    {
        name: "Graduated Cylinder (กระบอกตวง)",
        sizes: [
            { name: "10 mL", price: 150 },
            { name: "25 mL", price: 180 },
            { name: "50 mL", price: 220 },
            { name: "100 mL", price: 250 },
            { name: "250 mL", price: 350 },
            { name: "500 mL", price: 500 }
        ]
    },
    {
        name: "Pipette (ปิเปตต์)",
        sizes: [
            { name: "1 mL", price: 200 },
            { name: "2 mL", price: 220 },
            { name: "5 mL", price: 250 },
            { name: "10 mL", price: 300 },
            { name: "25 mL", price: 380 }
        ]
    },
    {
        name: "Burette (บิวเรตต์)",
        sizes: [
            { name: "25 mL", price: 750 },
            { name: "50 mL", price: 850 }
        ]
    },
    {
        name: "Test Tube (หลอดทดลอง)",
        sizes: [
            { name: "10x75 mm", price: 15 },
            { name: "15x150 mm", price: 25 },
            { name: "20x150 mm", price: 35 },
            { name: "25x200 mm", price: 50 }
        ]
    },
    {
        name: "Volumetric Flask (ขวดกำหนดปริมาตร)",
        sizes: [
            { name: "25 mL", price: 450 },
            { name: "50 mL", price: 500 },
            { name: "100 mL", price: 650 },
            { name: "250 mL", price: 800 },
            { name: "500 mL", price: 1100 },
            { name: "1000 mL", price: 1600 }
        ]
    },
    {
        name: "Funnel (กรวยกรอง)",
        sizes: [
            { name: "50 mm", price: 100 },
            { name: "75 mm", price: 120 },
            { name: "100 mm", price: 160 }
        ]
    },
    {
        name: "Condenser (คอนเดนเซอร์)",
        sizes: [
            { name: "300 mm (Liebig)", price: 1200 },
            { name: "300 mm (Graham)", price: 1500 },
            { name: "400 mm (Liebig)", price: 1600 }
        ]
    }
];

const defaultLabRoomsSettings = [
    "ห้องปฏิบัติการเคมีทั่วไป 101",
    "ห้องแล็บชีววิทยา 205",
    "ห้องแล็บเคมีอินทรีย์ 302",
    "ห้องวิเคราะห์คุณภาพน้ำ 405"
];

const defaultSizesSettings = [
    "50 mL",
    "100 mL",
    "250 mL",
    "500 mL",
    "1000 mL",
    "10 mL",
    "25 mL",
    "15x150 mm",
    "20x150 mm"
];

const defaultSubjectsSettings = [
    "ว30221 เคมี 1",
    "ว30222 เคมี 2",
    "ว30223 เคมี 3",
    "แล็บเคมีวิเคราะห์ SC211",
    "แล็บเคมีอินทรีย์ SC212",
    "วิทยาศาสตร์กายภาพทั่วไป"
];

const defaultCausesSettings = [
    "ลื่นหลุดมือ / หล่นพื้น",
    "แตกขณะล้างทำความสะอาด",
    "อุณหภูมิเปลี่ยนฉับพลัน (Thermal Shock)",
    "กระแทกกันระหว่างหยิบจับหรือเคลื่อนย้าย"
];

function loadSettings() {
    try {
        const stored = localStorage.getItem(SETTINGS_KEY);
        if (stored) {
            settings = JSON.parse(stored);
            // Backwards compatibility/migration checks
            if (!settings.glasswareTypes) {
                settings.glasswareTypes = defaultGlasswareSettings;
            } else {
                // Migrate old glasswareTypes schema
                settings.glasswareTypes = settings.glasswareTypes.map(t => {
                    if (t.defaultPrice !== undefined && (!t.sizes || !Array.isArray(t.sizes))) {
                        return {
                            name: t.name,
                            sizes: [
                                { name: "ขนาดเริ่มต้น", price: t.defaultPrice || 0 }
                            ]
                        };
                    }
                    if (!t.sizes) {
                        t.sizes = [];
                    }
                    return t;
                });
            }
            if (!settings.labRooms) settings.labRooms = defaultLabRoomsSettings;
            if (!settings.sizes) settings.sizes = defaultSizesSettings;
            if (!settings.subjects) settings.subjects = defaultSubjectsSettings;
            if (!settings.causes) settings.causes = defaultCausesSettings;
        } else {
            // Initial settings seeder
            settings = {
                glasswareTypes: defaultGlasswareSettings,
                labRooms: defaultLabRoomsSettings,
                sizes: defaultSizesSettings,
                subjects: defaultSubjectsSettings,
                causes: defaultCausesSettings
            };
            saveSettings();
        }
    } catch (e) {
        showToast("ไม่สามารถโหลดการตั้งค่าระบบได้: " + e.message, "danger");
        settings = { 
            glasswareTypes: defaultGlasswareSettings, 
            labRooms: defaultLabRoomsSettings,
            sizes: defaultSizesSettings,
            subjects: defaultSubjectsSettings,
            causes: defaultCausesSettings
        };
    }
    populateFormOptions();
}

function saveSettings() {
    try {
        localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    } catch (e) {
        showToast("ไม่สามารถบันทึกการตั้งค่าลงเบราว์เซอร์ได้: " + e.message, "danger");
    }
}

function populateSizesDropdownForSelectedType(selectedSizeVal = "") {
    const typeSelect = document.getElementById("field-type");
    const sizeSelect = document.getElementById("field-size");
    if (!typeSelect || !sizeSelect) return;
    
    const selectedType = typeSelect.value;
    sizeSelect.innerHTML = '<option value="">เลือกขนาด / ความจุ...</option>';
    
    if (selectedType === "อื่นๆ" || !selectedType) {
        // Use generic sizes from settings.sizes
        if (settings.sizes) {
            settings.sizes.forEach(size => {
                const opt = document.createElement("option");
                opt.value = size;
                opt.textContent = size;
                sizeSelect.appendChild(opt);
            });
        }
    } else {
        // Use nested sizes for the selected glassware type
        const found = settings.glasswareTypes.find(t => t.name === selectedType);
        if (found && found.sizes) {
            found.sizes.forEach(sizeObj => {
                const opt = document.createElement("option");
                opt.value = sizeObj.name;
                opt.textContent = sizeObj.name;
                sizeSelect.appendChild(opt);
            });
        }
    }
    
    // Add "อื่นๆ" option
    const otherOpt = document.createElement("option");
    otherOpt.value = "อื่นๆ";
    otherOpt.textContent = "อื่นๆ (ระบุในช่องขนาดอื่น)";
    sizeSelect.appendChild(otherOpt);
    
    // Restore or set selected value if valid
    if (selectedSizeVal) {
        sizeSelect.value = selectedSizeVal;
    }
}

function populateFormOptions() {
    const typeSelect = document.getElementById("field-type");
    const roomSelect = document.getElementById("field-room");
    const subjectSelect = document.getElementById("field-subject");
    const causeSelect = document.getElementById("field-cause");
    
    if (!typeSelect || !roomSelect || !subjectSelect || !causeSelect) return;
    
    // 1. Populate Glassware Types select
    const selectedType = typeSelect.value;
    typeSelect.innerHTML = '<option value="">เลือกประเภทเครื่องแก้ว...</option>';
    
    settings.glasswareTypes.forEach(t => {
        const opt = document.createElement("option");
        opt.value = t.name;
        opt.textContent = t.name;
        typeSelect.appendChild(opt);
    });
    
    // Add "อื่นๆ" at the end
    const otherTypeOpt = document.createElement("option");
    otherTypeOpt.value = "อื่นๆ";
    otherTypeOpt.textContent = "อื่นๆ (ระบุในช่องประเภทอื่น)";
    typeSelect.appendChild(otherTypeOpt);
    
    // Restore value if existed
    if (selectedType) typeSelect.value = selectedType;
    
    // 2. Populate Sizes select based on currently selected type
    populateSizesDropdownForSelectedType();
    
    // 3. Populate Lab Rooms select
    const selectedRoom = roomSelect.value;
    roomSelect.innerHTML = '<option value="">เลือกห้องปฏิบัติการ...</option>';
    
    settings.labRooms.forEach(room => {
        const opt = document.createElement("option");
        opt.value = room;
        opt.textContent = room;
        roomSelect.appendChild(opt);
    });
    
    // Add "อื่นๆ" at the end
    const otherRoomOpt = document.createElement("option");
    otherRoomOpt.value = "อื่นๆ";
    otherRoomOpt.textContent = "อื่นๆ (ระบุในช่องห้องแล็บอื่น)";
    roomSelect.appendChild(otherRoomOpt);
    
    // Restore value if existed
    if (selectedRoom) roomSelect.value = selectedRoom;

    // 4. Populate Subjects select
    const selectedSubject = subjectSelect.value;
    subjectSelect.innerHTML = '<option value="">เลือกรายวิชา...</option>';
    
    settings.subjects.forEach(subject => {
        const opt = document.createElement("option");
        opt.value = subject;
        opt.textContent = subject;
        subjectSelect.appendChild(opt);
    });
    
    const otherSubjectOpt = document.createElement("option");
    otherSubjectOpt.value = "อื่นๆ";
    otherSubjectOpt.textContent = "อื่นๆ (ระบุในช่องรายวิชาอื่น)";
    subjectSelect.appendChild(otherSubjectOpt);
    
    if (selectedSubject) subjectSelect.value = selectedSubject;

    // 5. Populate Causes select
    const selectedCause = causeSelect.value;
    causeSelect.innerHTML = '<option value="">เลือกสาเหตุการชำรุด...</option>';
    
    settings.causes.forEach(cause => {
        const opt = document.createElement("option");
        opt.value = cause;
        opt.textContent = cause;
        causeSelect.appendChild(opt);
    });
    
    const otherCauseOpt = document.createElement("option");
    otherCauseOpt.value = "อื่นๆ";
    otherCauseOpt.textContent = "อื่นๆ (ระบุในช่องสาเหตุอื่น)";
    causeSelect.appendChild(otherCauseOpt);
    
    if (selectedCause) causeSelect.value = selectedCause;
}

function updateTotalCostPreview() {
    const priceVal = parseFloat(document.getElementById("field-price").value) || 0.0;
    const qtyVal = parseInt(document.getElementById("field-quantity").value) || 0;
    const total = priceVal * qtyVal;
    
    const previewEl = document.getElementById("form-total-cost-preview");
    if (previewEl) {
        previewEl.textContent = `มูลค่าความเสียหายรวม: ${total.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})} บาท`;
    }
}

function renderSettingsTypes() {
    const tbody = document.getElementById("settings-types-tbody");
    if (!tbody) return;
    tbody.innerHTML = "";
    
    if (settings.glasswareTypes.length === 0) {
        tbody.innerHTML = `<tr><td colspan="3" class="empty-state">ไม่มีข้อมูลประเภทเครื่องแก้ว</td></tr>`;
        return;
    }
    
    settings.glasswareTypes.forEach((t, index) => {
        const row = document.createElement("tr");
        const sizeCount = t.sizes ? t.sizes.length : 0;
        row.innerHTML = `
            <td><strong>${t.name}</strong></td>
            <td><strong>${sizeCount} ขนาด</strong></td>
            <td style="text-align:center;">
                <button class="btn btn-outline btn-sm" onclick="openSizesModal(${index})" style="padding: 0.25rem 0.5rem; font-size: 0.75rem; margin-right: 0.5rem; display: inline-flex; align-items: center; gap: 0.25rem;">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14">
                        <circle cx="12" cy="12" r="3"></circle>
                        <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
                    </svg>
                    ขนาด/ราคา
                </button>
                <button class="btn-icon btn-icon-delete" onclick="deleteSettingsType(${index})" title="ลบประเภทเครื่องแก้ว">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16">
                        <polyline points="3 6 5 6 21 6" />
                        <path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2" />
                    </svg>
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function renderSettingsSizes() {
    const tbody = document.getElementById("settings-sizes-tbody");
    if (!tbody) return;
    tbody.innerHTML = "";
    
    if (!settings.sizes || settings.sizes.length === 0) {
        tbody.innerHTML = `<tr><td colspan="2" class="empty-state">ไม่มีข้อมูลขนาด / ความจุ</td></tr>`;
        return;
    }
    
    settings.sizes.forEach((size, index) => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td><strong>${size}</strong></td>
            <td style="text-align:center;">
                <button class="btn-icon btn-icon-delete" onclick="deleteSettingsSize(${index})" title="ลบขนาด / ความจุ">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16">
                        <polyline points="3 6 5 6 21 6" />
                        <path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2" />
                    </svg>
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function renderSettingsSubjects() {
    const tbody = document.getElementById("settings-subjects-tbody");
    if (!tbody) return;
    tbody.innerHTML = "";
    
    if (!settings.subjects || settings.subjects.length === 0) {
        tbody.innerHTML = `<tr><td colspan="2" class="empty-state">ไม่มีข้อมูลรายวิชา / รหัสวิชา</td></tr>`;
        return;
    }
    
    settings.subjects.forEach((subject, index) => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td><strong>${subject}</strong></td>
            <td style="text-align:center;">
                <button class="btn-icon btn-icon-delete" onclick="deleteSettingsSubject(${index})" title="ลบรายวิชา">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16">
                        <polyline points="3 6 5 6 21 6" />
                        <path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2" />
                    </svg>
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function renderSettingsRooms() {
    const tbody = document.getElementById("settings-rooms-tbody");
    if (!tbody) return;
    tbody.innerHTML = "";
    
    if (settings.labRooms.length === 0) {
        tbody.innerHTML = `<tr><td colspan="2" class="empty-state">ไม่มีข้อมูลรายชื่อห้องปฏิบัติการ</td></tr>`;
        return;
    }
    
    settings.labRooms.forEach((room, index) => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td><strong>${room}</strong></td>
            <td style="text-align:center;">
                <button class="btn-icon btn-icon-delete" onclick="deleteSettingsRoom(${index})" title="ลบห้องปฏิบัติการ">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16">
                        <polyline points="3 6 5 6 21 6" />
                        <path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2" />
                    </svg>
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function renderSettingsCauses() {
    const tbody = document.getElementById("settings-causes-tbody");
    if (!tbody) return;
    tbody.innerHTML = "";
    
    if (!settings.causes || settings.causes.length === 0) {
        tbody.innerHTML = `<tr><td colspan="2" class="empty-state">ไม่มีข้อมูลตัวเลือกสาเหตุชำรุด</td></tr>`;
        return;
    }
    
    settings.causes.forEach((cause, index) => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td><strong>${cause}</strong></td>
            <td style="text-align:center;">
                <button class="btn-icon btn-icon-delete" onclick="deleteSettingsCause(${index})" title="ลบสาเหตุการชำรุด">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16">
                        <polyline points="3 6 5 6 21 6" />
                        <path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2" />
                    </svg>
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

// Global hookup functions for inline onclick triggers
window.deleteSettingsType = function(index) {
    if (currentUserRole !== "admin") return;
    settings.glasswareTypes.splice(index, 1);
    saveSettings();
    renderSettingsTypes();
    populateFormOptions();
    populateFilterDropdowns();
};

window.deleteSettingsSize = function(index) {
    if (currentUserRole !== "admin") return;
    settings.sizes.splice(index, 1);
    saveSettings();
    renderSettingsSizes();
    populateFormOptions();
};

window.deleteSettingsSubject = function(index) {
    if (currentUserRole !== "admin") return;
    settings.subjects.splice(index, 1);
    saveSettings();
    renderSettingsSubjects();
    populateFormOptions();
};

window.deleteSettingsRoom = function(index) {
    if (currentUserRole !== "admin") return;
    settings.labRooms.splice(index, 1);
    saveSettings();
    renderSettingsRooms();
    populateFormOptions();
    populateFilterDropdowns();
};

window.deleteSettingsCause = function(index) {
    if (currentUserRole !== "admin") return;
    settings.causes.splice(index, 1);
    saveSettings();
    renderSettingsCauses();
    populateFormOptions();
    populateFilterDropdowns();
};

function setupSettingsListeners() {
    const typeForm = document.getElementById("settings-type-form");
    const sizeForm = document.getElementById("settings-size-form");
    const subjectForm = document.getElementById("settings-subject-form");
    const roomForm = document.getElementById("settings-room-form");
    const causeForm = document.getElementById("settings-cause-form");
    
    if (typeForm) {
        typeForm.addEventListener("submit", (e) => {
            e.preventDefault();
            if (currentUserRole !== "admin") return;
            
            const nameInput = document.getElementById("settings-type-name");
            const nameVal = nameInput.value.trim();
            
            // Check duplicates
            const isDup = settings.glasswareTypes.some(t => t.name.toLowerCase() === nameVal.toLowerCase());
            if (isDup) {
                showToast("มีประเภทเครื่องแก้วนี้ในระบบอยู่แล้ว", "warning");
                return;
            }
            
            settings.glasswareTypes.push({ name: nameVal, sizes: [] });
            saveSettings();
            
            // Clear inputs
            nameInput.value = "";
            
            renderSettingsTypes();
            populateFormOptions();
            populateFilterDropdowns();
        });
    }

    if (sizeForm) {
        sizeForm.addEventListener("submit", (e) => {
            e.preventDefault();
            if (currentUserRole !== "admin") return;
            
            const nameInput = document.getElementById("settings-size-name");
            const nameVal = nameInput.value.trim();
            
            const isDup = settings.sizes.some(s => s.toLowerCase() === nameVal.toLowerCase());
            if (isDup) {
                showToast("มีขนาด / ความจุนี้ในระบบอยู่แล้ว", "warning");
                return;
            }
            
            settings.sizes.push(nameVal);
            saveSettings();
            
            nameInput.value = "";
            
            renderSettingsSizes();
            populateFormOptions();
        });
    }

    if (subjectForm) {
        subjectForm.addEventListener("submit", (e) => {
            e.preventDefault();
            if (currentUserRole !== "admin") return;
            
            const nameInput = document.getElementById("settings-subject-name");
            const nameVal = nameInput.value.trim();
            
            const isDup = settings.subjects.some(s => s.toLowerCase() === nameVal.toLowerCase());
            if (isDup) {
                showToast("มีรายวิชา / รหัสวิชานี้ในระบบอยู่แล้ว", "warning");
                return;
            }
            
            settings.subjects.push(nameVal);
            saveSettings();
            
            nameInput.value = "";
            
            renderSettingsSubjects();
            populateFormOptions();
        });
    }
    
    if (roomForm) {
        roomForm.addEventListener("submit", (e) => {
            e.preventDefault();
            if (currentUserRole !== "admin") return;
            
            const nameInput = document.getElementById("settings-room-name");
            const nameVal = nameInput.value.trim();
            
            // Check duplicates
            const isDup = settings.labRooms.some(r => r.toLowerCase() === nameVal.toLowerCase());
            if (isDup) {
                showToast("มีห้องปฏิบัติการนี้ในระบบอยู่แล้ว", "warning");
                return;
            }
            
            settings.labRooms.push(nameVal);
            saveSettings();
            
            nameInput.value = "";
            
            renderSettingsRooms();
            populateFormOptions();
            populateFilterDropdowns();
        });
    }

    if (causeForm) {
        causeForm.addEventListener("submit", (e) => {
            e.preventDefault();
            if (currentUserRole !== "admin") return;
            
            const nameInput = document.getElementById("settings-cause-name");
            const nameVal = nameInput.value.trim();
            
            const isDup = settings.causes.some(c => c.toLowerCase() === nameVal.toLowerCase());
            if (isDup) {
                showToast("มีสาเหตุชำรุดนี้ในระบบอยู่แล้ว", "warning");
                return;
            }
            
            settings.causes.push(nameVal);
            saveSettings();
            
            nameInput.value = "";
            
            renderSettingsCauses();
            populateFormOptions();
            populateFilterDropdowns();
        });
    }
}

// Sizes Modal functions
window.openSizesModal = function(index) {
    if (currentUserRole !== "admin") return;
    const type = settings.glasswareTypes[index];
    if (!type) return;
    
    document.getElementById("modal-size-type-index").value = index;
    document.getElementById("sizes-modal-title").textContent = `จัดการขนาดและราคา - ${type.name}`;
    
    // Clear modal inputs
    document.getElementById("modal-size-name").value = "";
    document.getElementById("modal-size-price").value = "";
    
    renderModalSizes(index);
    
    const modal = document.getElementById("sizes-modal");
    if (modal) {
        modal.style.display = "flex";
    }
};

window.hideSizesModal = function() {
    const modal = document.getElementById("sizes-modal");
    if (modal) {
        modal.style.display = "none";
    }
};

function renderModalSizes(typeIndex) {
    const tbody = document.getElementById("modal-sizes-tbody");
    if (!tbody) return;
    tbody.innerHTML = "";
    
    const type = settings.glasswareTypes[typeIndex];
    if (!type || !type.sizes || type.sizes.length === 0) {
        tbody.innerHTML = `<tr><td colspan="3" class="empty-state">ยังไม่มีข้อมูลขนาดและราคาเฉพาะเจาะจง</td></tr>`;
        return;
    }
    
    type.sizes.forEach((s, idx) => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td><strong>${s.name}</strong></td>
            <td><strong>${parseFloat(s.price).toLocaleString(undefined, {minimumFractionDigits: 2})}</strong></td>
            <td style="text-align:center;">
                <button class="btn-icon btn-icon-delete" onclick="deleteModalSize(${typeIndex}, ${idx})" title="ลบขนาดนี้">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16">
                        <polyline points="3 6 5 6 21 6" />
                        <path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2" />
                    </svg>
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

window.deleteModalSize = function(typeIndex, sizeIdx) {
    if (currentUserRole !== "admin") return;
    const type = settings.glasswareTypes[typeIndex];
    if (type && type.sizes) {
        type.sizes.splice(sizeIdx, 1);
        saveSettings();
        renderModalSizes(typeIndex);
        renderSettingsTypes();
        populateFormOptions();
    }
};

function setupSizesModal() {
    const closeBtn = document.getElementById("btn-close-sizes-modal");
    const closeOkBtn = document.getElementById("btn-close-sizes-modal-ok");
    
    if (closeBtn) closeBtn.addEventListener("click", hideSizesModal);
    if (closeOkBtn) closeOkBtn.addEventListener("click", hideSizesModal);
    
    const modalSizeForm = document.getElementById("modal-size-form");
    if (modalSizeForm) {
        modalSizeForm.addEventListener("submit", (e) => {
            e.preventDefault();
            if (currentUserRole !== "admin") return;
            
            const typeIndex = parseInt(document.getElementById("modal-size-type-index").value);
            const nameInput = document.getElementById("modal-size-name");
            const priceInput = document.getElementById("modal-size-price");
            
            const sizeName = nameInput.value.trim();
            const sizePrice = parseFloat(priceInput.value) || 0.0;
            
            const type = settings.glasswareTypes[typeIndex];
            if (type) {
                if (!type.sizes) type.sizes = [];
                
                // Check duplicate size
                const isDup = type.sizes.some(s => s.name.toLowerCase() === sizeName.toLowerCase());
                if (isDup) {
                    showToast("มีขนาด / ความจุนี้สำหรับเครื่องแก้วประเภทนี้อยู่แล้ว", "warning");
                    return;
                }
                
                type.sizes.push({ name: sizeName, price: sizePrice });
                saveSettings();
                
                nameInput.value = "";
                priceInput.value = "";
                
                renderModalSizes(typeIndex);
                renderSettingsTypes();
                populateFormOptions();
            }
        });
    }
}
